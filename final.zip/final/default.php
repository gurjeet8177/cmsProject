<?php

 ob_start(); 

?>


   <?php
$page_title=null;
$page_title="ALL hotels";
require_once('header.php');
?>


<h1>hotels are up there</h1>

<?php
require_once('footer.php');
?>
<?php ob_flush(); ?>