<?php
$page_title = 'COMP1006 App - Page Not Found';

require_once('header.php');

?>
<main class="container">

     <h1>Ooops!</h1>

     <p class="jumbotron">Sorry but we can't find the page you requested.  Please try one of the links above instead.</p>

</main>
<?php
require_once('footer.php');
?>