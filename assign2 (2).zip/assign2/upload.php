<form method="post" action="save-upload.php" enctype="multipart/form-data">

    Choose any file: <input type="file" name="upload" />
    <button type="submit">Submit</button>

</form>